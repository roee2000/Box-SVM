#include "Input.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
using namespace std;
  
Input::Input(string const &jobname_) : jobname(jobname_)
{
	size_t notfound = string::npos;
	ifstream inputfile;
	std::string buffer, line, word;

	/*  open inputfile  */
	cout << "\t open input file " << jobname << endl;
	inputfile.open(jobname);


	/*   read inputfile and remove all comment lines  */
	buffer.clear();
	while (getline(inputfile, line))
	{
		int ignore = line.find('!');
		if (ignore != notfound)
			line = line.substr(0, ignore);
		if (line.length() == 0)
			line = " ";
		buffer.append(line);
	}
	
	/*                  remove all '=' signs from buffer         */
	std::replace(buffer.begin(), buffer.end(), '=', ' ');
	
	/*                  initialize some variables */
    dmaxHigh = 0; dmaxLow = 0;
	vpot3b = 0. ; apot3b = 0.;
	/*                  read data from buffer */
	istringstream iss(buffer);
	while (iss >> word){
		if (word == "npar") {
			npar = rdai(iss);
			mass.resize(npar);
			charges.resize(npar);
		}
		else if (word == "h2m") h2m = rdaf(iss);
		else if (word == "hh" ) h2m = rdaf(iss);
                else if (word == "BoxSize") BoxSize = rdaf(iss);
        else if (word == "dmax") {
            int a = rdai(iss);
            dmaxLow = a;
            dmaxHigh = a;
        }
        else if (word == "dmaxHigh") dmaxHigh = rdai(iss);
        else if (word == "PD1Low") PD1Low = rdai(iss);
        else if (word == "PD2Low") PD2Low = rdai(iss);
        else if (word == "PD1High") PD1High = rdai(iss);
        else if (word == "PD2High") PD2High = rdai(iss);
        else if (word == "dmaxLow") dmaxLow = rdai(iss);
        else if (word == "amin") rndmin = rdaf(iss);
		else if (word == "amax") rndmax = rdaf(iss);
		else if (word == "irand") irand = rdai(iss);
		else if (word == "ibf") bosefermi = rdai(iss);
		else if (word == "ico") keycontinue = rdai(iss);
		else if (word == "mnb") maxbasis = rdai(iss);
		else if (word == "mm0") mm0 = rdai(iss);
		else if (word == "kk0") kk0 = rdai(iss);
		else if (word == "vpot3b") vpot3b = rdaf(iss);
		else if (word == "apot3b") apot3b = rdaf(iss);
		else if (word == "nop") { nop = rdai(iss); potop.resize(nop); }
		else if (word == "npt") npt = rdai(iss);
		else if (word.find("xm") != notfound) {
			for (int i = 0; i < npar; i++) mass[i] = rdaf(iss);
		}
		else if (word.find("z") != notfound) {
			for (int i = 0; i < npar; i++) charges[i] = rdaf(iss);
		}
		else if (word.find("vpot") != notfound) rdpot(word, iss);
		else if (word.find("apot") != notfound) rdpot(word, iss);
		else if (word.find("bpot") != notfound) rdpot(word, iss);
		else if (word.find("npot") != notfound) rdpot(word, iss);
		else if (word == "nisc") {
			int ncmp = rdai(iss);
			isospin.ncmp = ncmp; isospin.coef.resize(ncmp); isospin.cmp.resize(ncmp, npar);
		}
		else if (word == "nspc") {
			int ncmp = rdai(iss);
			spin.ncmp = ncmp; spin.coef.resize(ncmp); spin.cmp.resize(ncmp, npar);
		}
		else if (word.find("cisc") != notfound) rdts(word, iss);
		else if (word.find("cspc") != notfound) rdts(word, iss);
		else if (word.find("iso(") != notfound) rdts(word, iss);
		else if (word.find("isp(") != notfound) rdts(word, iss);
	}
    dmax = dmaxHigh;
	inputfile.close();
}

////=============================================================================
double Input::rdaf(istringstream& iss)
{
	double f;
	string c;

	if (!(iss >> f)) { iss.clear(); iss >> c; iss >> f; }
	return f;
}
////=============================================================================
int Input::rdai(istringstream& iss)
{
	int i;
	string c;

	if (!(iss >> i)) { iss.clear(); iss >> c; iss >> i; }
	return i;
}
////=============================================================================
void Input::rdpot(string& word, istringstream& iss)
{
	int iop, iterm, i1, i2, i3, key3b;
	string comp;
	double f;

	key3b = word.find("3b");
	if (key3b == string::npos) key3b = -1;

	if (key3b == -1) {
		i1 = word.find("("); i2 = word.find(","); i3 = word.find(")");
		iterm = stoi(word.substr(i1 + 1, i2 - i1 - 1));
		iop = stoi(word.substr(i2 + 1, i3 - i2 - 1));
		comp = word.substr(0, 4);
		if (comp == "vpot") {
			iss >> potop[iop - 1].vpot[iterm - 1];
			potop[iop - 1].nterms++;
		}
		if (comp == "apot") iss >> potop[iop - 1].aquad[iterm - 1];
		if (comp == "bpot") iss >> potop[iop - 1].alin[iterm - 1];
		if (comp == "npot") iss >> potop[iop - 1].npow[iterm - 1];
	}
}
////=============================================================================
void Input::rdts(string& word, istringstream& iss)
{
	int ipar, icmp, i1, i2, i3, keyts;
	size_t notfound = string::npos;
	string caux;
	double f;

	if (word.find("iso") != notfound) {
		i1 = word.find("("); i2 = word.find(","); i3 = word.find(")");
		ipar = stoi(word.substr(i1 + 1, i2 - i1 - 1));
		icmp = stoi(word.substr(i2 + 1, i3 - i1 - 1));
		iss >> isospin.cmp[icmp - 1].tz[ipar - 1];
	}
	if (word.find("isp") != notfound) {
		i1 = word.find("("); i2 = word.find(","); i3 = word.find(")");
		ipar = stoi(word.substr(i1 + 1, i2 - i1 - 1));
		icmp = stoi(word.substr(i2 + 1, i3 - i1 - 1));
		iss >> spin.cmp[icmp - 1].sz[ipar - 1];
	}
	if (word.find("cisc") != notfound) {
		i1 = word.find("("); i3 = word.find(")");
		icmp = stoi(word.substr(i1 + 1, i3 - i1 - 1));
		iss >> isospin.coef[icmp - 1];
	}
	if (word.find("cspc") != notfound) {
		i1 = word.find("("); i3 = word.find(")");
		icmp = stoi(word.substr(i1 + 1, i3 - i1 - 1));
		iss >> spin.coef[icmp - 1];
	}
}
//=============================================================================
void Input::print(void){}

Input::~Input(){}
