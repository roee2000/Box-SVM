#ifndef MatrixElement_H
#define MatrixElement_H
#include "Input.h"
#include <vector>
#include <Eigen>
using namespace Eigen;

class MatrixElement
{
private:
    const double pi = 3.14159265359;
    long double PD1, PD2;
    double h2m, L, apot3b, vpot3b;
    std::vector<VectorXd> bbox, bboxOri; //vector of cells
    std::vector<MatrixXd> PM;
    std::vector<MatrixXd> NonZeroPM;
    std::vector<VectorXi> PV;
    std::vector<int> parity;
    std::vector<VectorXd> TBP;
    int npar, npt, nop, dmax, nPairs, nPerm, nConf,ibf;
    std::vector<double> stme;
    MatrixXd vpot, apot;
    MatrixXd mass;
    MatrixXd U;
    MatrixXd Ured;
    void PreparePotential(Input &input);
    void PrepareSpinIsospinME(Input &input);
    int iBoxInf;
    double MatrixVectorProd(VectorXd v1, MatrixXd O, VectorXd v2);
    int nextConf(int iConf);

public:
    MatrixElement(Input &input, int HighLow);
    ~MatrixElement();
    double overlap(std::vector<MatrixXd> state1, std::vector<MatrixXd> state2);
    double energy(std::vector<MatrixXd> state1, std::vector<MatrixXd> state2);
};
#endif 
