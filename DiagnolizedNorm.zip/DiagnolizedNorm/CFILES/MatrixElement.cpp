#include "MatrixElement.h"
#include "Input.h"
#include "Operators.h"
#include "CoordinatsTransformation.h"
#include "Permutation.h"
#include <cmath>
#include <Eigen>
#include <vector>
//#include <mpi.h>

using namespace Eigen;
using namespace std;

vector<VectorXd> SumOverCellsNormal(int dmax, int npar);
vector<VectorXd> SumOverCellsJacobi(int dmax, int npar, MatrixXd Ured);

vector<VectorXd> TwoBodyPairs(int npar);

int factorial(int npar);

MatrixElement::MatrixElement(Input &input, int HighLow)
{
    //cout << "\t Initialize MatrixElement\n";
    npar = input.npar;
    h2m = input.h2m;
    if(HighLow == 1) PD2 = pow(0.1,input.PD2High);// for dmaxHigh, potential precision
    else PD2 = pow(0.1,input.PD2Low);//

    if(HighLow == 1) PD1 = pow(0.1,input.PD1High);// for dmaxHigh, spatial part precision
    else PD1 = pow(0.1,input.PD1Low);//

    if(HighLow == 1) dmax = input.dmaxHigh;
    else dmax = input.dmaxLow;

    nop = input.nop;
    npt = input.npt;
    ibf = input.bosefermi;  // ibf=2 for bosons.  ibf=1 for fermions
    L = input.BoxSize;
    apot3b = input.apot3b;
    vpot3b = input.vpot3b;
    nPairs = npar*(npar - 1) / 2;
    nPerm = factorial(npar);
    nConf = pow(2 * dmax + 1, npar-1); //number of cells configurations

    Permutation P(npar);
    PM = P.perm_matrix;
    PV = P.permutation;
    if(ibf==1) parity = P.parity; //fermions
    if (ibf == 2) for (int iperm = 0; iperm < nPerm; iperm++) parity.push_back(1); //bosons

    mass=MatrixXd::Zero(npar,npar);
    for (int imas = 0; imas < npar; imas++) mass(imas,imas)=input.mass[imas];

    TBP = TwoBodyPairs(npar);

    PrepareSpinIsospinME(input);
    PreparePotential(input);
    //----------- Define U and Ured the Coordinate Transformation matrices--------
    U = MatrixXd::Zero(npar, npar);
    Ured = MatrixXd::Zero(npar-1, npar-1);

    for (int i = 0; i < npar-1; i++){
        for (int j = 0; j < i+1; j++){
            U(i, j) = 1/sqrt((i+1)*(i+2));
        }
        U(i, i+1) = -sqrt(i+1)/sqrt(i+2);
    }

    for (int i = 0; i < npar; i++)
        U(npar-1, i) = 1/sqrt(npar);

    for (int i = 0; i < npar-1; i++){
        for (int j = 0; j < npar-1; j++){
            Ured(i, j) = U(i, j);
        }
    }
    bbox = SumOverCellsJacobi(dmax, npar, Ured);
    bboxOri = SumOverCellsNormal(dmax, npar);
}
//=============================================================================
double MatrixElement::overlap(std::vector<MatrixXd> state1, std::vector<MatrixXd> state2){
    MatrixXd A1 = state1[0];
    MatrixXd A2_0 = state2[0];
    MatrixXd A2;

    double overlap = 0; int layer, iConf;
    MatrixXd AA;
    MatrixXd InvAA, D1T = U*A1*U.transpose();
    MatrixXd D1 = MatrixXd::Zero(npar-1, npar-1);
    MatrixXd D2 = D1;
    VectorXd d;
    long double x4, x6;
    long double overlapB = 0, C, overlapBLayer;


    for (int iperm = 0; iperm < nPerm; iperm++) {   //sum over permutation
        iConf = 0;
        A2 = PM[iperm].transpose() * A2_0 * PM[iperm];
        MatrixXd D2T = U*A2*U.transpose();

        //--------------discard last line of D, D = D(1:N-1,1:N-1)---------------
        for (int i = 0; i < npar-1; i++){
            for (int j = 0; j < npar-1; j++){
                D1(i, j) = D1T(i, j);
                D2(i, j) = D2T(i, j);
            }
        }

        AA = D1 + D2; InvAA = AA.inverse();
        overlapB = 0; layer = 0; overlapBLayer = 1;
        while(abs(overlapBLayer)>abs(overlapB*PD1) && layer < dmax) {
            overlapBLayer = 0;
            for (iConf=iConf; iConf < pow(2*layer+1, npar-1); iConf++) {   //sum over cells
                d = L * D1 * bbox[iConf];
                x4 = 0.5 * d.transpose() * InvAA * d;
                x6 = -0.5 * L * L * bbox[iConf].transpose() * D1 * bbox[iConf];
                C = exp(x4 + x6);
                overlapBLayer = overlapBLayer + C;
            }
            overlapB = overlapB + overlapBLayer;
            layer++;
            //cout << "overlapBLayer = " << overlapBLayer << " overlapB = " << overlapB << endl;
            //cout << "layer = " << layer << endl;
        }
        overlapB = overlapB/sqrt(AA.determinant());
        overlap = overlap + parity[iperm] * stme[iperm*nPairs*nop] * pow(overlapB, 3);
    }
    return overlap;
}
//==============================================================================================
double MatrixElement::energy(std::vector<MatrixXd> state1, std::vector<MatrixXd> state2){
    MatrixXd A1 = state1[0];
    MatrixXd A2_0 = state2[0]; MatrixXd A2;

    MatrixXd AA;
    MatrixXd InvAA, D1T = U*A1*U.transpose();
    MatrixXd D1 = MatrixXd::Zero(npar-1, npar-1);
    MatrixXd D2 = D1;
    VectorXd d;

    VectorXd InvAAd;
    double PotEnergy = 0, KinEnergy = 0, PotEnergy3B = 0;

    //===========3-body===================
    MatrixXd B(2,2);
    MatrixXd I = MatrixXd::Identity(2,2);
    CoordinatsTransformation v(npar);
    VectorXd Cik(npar);
    VectorXd Cjk(npar);
    int i1, j1, k1;
    int layer, iConf;
    //====================================

    long double KinEnergyB, PotEnergyB, overlapK, PotEnergyBLayer;
    VectorXd yy;
    long double sqInvDetAA, x4, x5, x9;
    long double v3b;
    long double y1,y2,y3;
    long double z1, z2;
    long double s, r;

    //===========3-body===================
    double PotEnergy3BP = 0;
    MatrixXd BB(2,2);
    MatrixXd BBB(2,2);
    VectorXd e(2);
    double xx1, xx2, xx3, xx7, DeltaE;
    long double C, rC, Cpot, Cf;
    long double C3ik, C3jk, C3f;
    //====================================s



    for (int iperm = 0; iperm < nPerm; iperm++){   //sum over permutation

        A2 = PM[iperm].transpose() * A2_0 * PM[iperm];
        MatrixXd D2T = U*A2*U.transpose();

        //--------------discard last line of D, D = D(1:N-1,1:N-1)---------------
        for (int i = 0; i < npar-1; i++){
            for (int j = 0; j < npar-1; j++){
                D1(i, j) = D1T(i, j);
                D2(i, j) = D2T(i, j);
            }
        }
        AA = D1 + D2;
        InvAA = AA.inverse();
        sqInvDetAA = sqrt(1.0 / AA.determinant());

        //2B potential enegry=======================================
        for (int ipt = 0; ipt < npt; ipt++){
            for (int iop = 0; iop < nop; iop++){
                for (int ipair = 0; ipair < nPairs; ipair++){   //sum over pairs
                    if (stme[(iperm*nPairs+ipair)*nop+iop]*vpot(iop, ipt) == 0)
                        break;
                    int r1, r2; // the number of the first and second particle in the interaction
                    VectorXd JTBPTemp = U*TBP[ipair];
                    for(int i=0; i<npar; i++){
                        if(TBP[ipair][i] == 1)
                            r1 = i;
                        if(TBP[ipair][i] == -1)
                            r2 = i;
                    }
                    VectorXd JTBP = VectorXd::Zero(npar-1);
                    for (int i = 0; i < npar-1; i++)
                        JTBP[i] = JTBPTemp[i];

                    s = JTBP.transpose() * InvAA * JTBP;
                    x9 = sqInvDetAA*sqrt(1.0 / (2.0*apot(iop, ipt) *s + 1));
                    C = apot(iop, ipt)/(2.0*apot(iop, ipt)*s + 1);
                    PotEnergyB=0;  layer = 0; PotEnergyBLayer = 1; iConf = 0;
                    while(abs(PotEnergyBLayer)>abs(PotEnergyB*PD1) && layer < dmax) { //sum over layers until saturation
                        PotEnergyBLayer = 0;
                        for (iConf = iConf; iConf < pow(2 * layer + 1, npar - 1); iConf++) {   //sum over cells
                            d = L * D1 * bbox[iConf];
                            InvAAd = InvAA * d;
                            x4 = 0.5 * d.transpose() * InvAA * d;
                            x5 = -0.5 * L * L * bbox[iConf].transpose() * D1 * bbox[iConf];
                            rC = JTBP.transpose() * InvAAd;
                            Cpot = x9 * exp(x4 + x5);
                            int C0 = (int) (rC / L + 0.5);//bboxOri[iConf][r1] - bboxOri[iConf][r2];

                            r = -L * C0 + rC;
                            Cf = Cpot * exp(-r * r * C);
                            PotEnergyBLayer = PotEnergyBLayer + Cf;
                            //cout << "C0 = " << C0 << " rC = " << rC << " Cf = " << Cf << " for q = " << 0 << endl;
                            for (int q = 1; q <= dmax; q++) {
                                r = -L * (C0 + q) + rC;
                                Cf = Cpot * exp(-r * r * C);
                                r = -L * (C0 - q) + rC;
                                Cf = Cf + Cpot * exp(-r * r * C);
                                PotEnergyBLayer = PotEnergyBLayer + Cf;
                                //cout << "PB = " << PotEnergyB*PD2 << " Cf = " << Cf << " for q = " << q << endl;
                                if (abs(PotEnergyB * PD2) > abs(Cf))
                                    break;
                            }
                        }
                        layer++;
                        PotEnergyB =  PotEnergyB + PotEnergyBLayer;
                        //cout << "PotEnergyBLayer = " << PotEnergyBLayer << " PotEnergyB = " << PotEnergyB << endl;
                        //cout << "layer = " << layer << endl;
                    }
                    PotEnergy = PotEnergy + parity[iperm] *stme[(iperm*nPairs+ipair)*nop+iop]
                                            *vpot(iop, ipt) *pow(PotEnergyB,3);
                }
            }
        }
        //kinetic energy================================

        y1 = (D1 * InvAA * D2).trace();

        KinEnergyB = 0;
        overlapK = 0;
        for (int iConf = 0; iConf < nConf; iConf++){   //sum over cells
            d = L*D1*bbox[iConf];
            yy = D2*InvAA*d; y2 = yy.transpose()*yy;
            z1 = 0.5*d.transpose()*InvAA*d;
            z2 = -0.5*L*L*bbox[iConf].transpose()*D1*bbox[iConf];
            y3 = sqInvDetAA*exp(z1+z2);
            overlapK = overlapK + y3;
            KinEnergyB = KinEnergyB + (y1-y2)*y3;
        }
        KinEnergy = KinEnergy + parity[iperm] *stme[iperm*nPairs*nop] *KinEnergyB*overlapK*overlapK;
        VectorXd TCik, TCjk;
        //====================================
        if(npar>2 && stme[iperm*nPairs*nop] != 0){
            PotEnergy3BP = 0;
            for (int i = 0; i < npar; i++){
                for (int j = i + 1; j < npar; j++){
                    for (int k = j + 1; k < npar; k++){
                        for (int cyc = 0; cyc < 3; cyc++){
                            if (cyc == 0) {i1 = i; j1 = j; k1 = k;}
                            if (cyc == 1) {i1 = j; j1 = k; k1 = i;}
                            if (cyc == 2) {i1 = k; j1 = i; k1 = j;}

                            TCik = v.SingleParticle(i1, k1);
                            TCjk = v.SingleParticle(j1, k1);
                            TCik = U*TCik; TCjk = U*TCjk;

                            Cik = VectorXd::Zero(npar-1);
                            Cjk = VectorXd::Zero(npar-1);
                            for (int i = 0; i < npar-1; i++){
                                Cik[i] = TCik[i];
                                Cjk[i] = TCjk[i];
                            }

                            B(0,0) = Cik.transpose()*InvAA*Cik;
                            B(0,1) = Cik.transpose()*InvAA*Cjk;
                            B(1,0) = Cjk.transpose()*InvAA*Cik;
                            B(1,1) = Cjk.transpose()*InvAA*Cjk;
                            BB = I+2.0*apot3b*B;
                            BBB = B.inverse()*(I-BB.inverse());
                            xx1 = sqrt(1.0 / BB.determinant());

                            double DeltaE;
                            PotEnergyB = 0; layer = 0; PotEnergyBLayer = 1; iConf = 0;
                            while(abs(PotEnergyBLayer)>abs(PotEnergyB*PD1) && layer < dmax) {
                                PotEnergyBLayer = 0;
                                for (iConf=iConf; iConf < pow(2*layer+1, npar-1); iConf++) {   //sum over cells
                                    d = L * D1 * bbox[iConf];
                                    xx2 = 0.5 * d.transpose() * InvAA * d;
                                    xx3 = -0.5 * L * L * bbox[iConf].transpose() * D1 * bbox[iConf];
                                    C3f = sqInvDetAA * exp(xx2 + xx3) * xx1;
                                    C3ik = d.transpose() * InvAA * Cik;
                                    C3jk = d.transpose() * InvAA * Cjk;

                                    int C0 = round(C3ik / L);
                                    int C1 = round(C3jk / L);

                                    //------------------run for q1 = 0------------------//
                                    e(0) = C3ik - L * C0;
                                    // calculate q2 = 0
                                    e(1) = C3jk - L * C1;
                                    xx7 = C3f * exp(-0.5 * e.transpose() * BBB * e);
                                    PotEnergyBLayer = PotEnergyBLayer + xx7;
                                    for (int q2 = 1; q2 <= dmax; q2++) {
                                        e(1) = C3jk - L * (C1 + q2);
                                        xx7 = C3f * exp(-0.5 * e.transpose() * BBB * e);
                                        e(1) = C3jk - L * (C1 - q2);
                                        xx7 = xx7 + C3f * exp(-0.5 * e.transpose() * BBB * e);
                                        PotEnergyBLayer = PotEnergyBLayer + xx7;
                                        if (abs(PotEnergyB * PD2) > abs(xx7))
                                            break;
                                    }
                                    //---------------------end q1 = 0---------------------//
                                    //cout << "C0 = " << C0 << " C3ik = " << C3ik << " C3jk = " << C3jk << " C1 = " << C1 << endl;
                                    for (int q1 = 1; q1 <= dmax; q1++) {
                                        DeltaE = 0;
                                        e(0) = C3ik - L * (C0 + q1);
                                        // calculate q2 = 0
                                        e(1) = C3jk - L * C1;
                                        DeltaE = C3f * exp(-0.5 * e.transpose() * BBB * e);
                                        for (int q2 = 1; q2 <= dmax; q2++) {
                                            e(1) = C3jk - L * (C1 + q2);
                                            xx7 = C3f * exp(-0.5 * e.transpose() * BBB * e);
                                            e(1) = C3jk - L * (C1 - q2);
                                            xx7 = xx7 + C3f * exp(-0.5 * e.transpose() * BBB * e);
                                            DeltaE = DeltaE + xx7;
                                            if (abs(PotEnergyB * PD2) > abs(xx7))
                                                break;
                                        }

                                        e(0) = C3ik - L * (C0 - q1);
                                        // calculate q2 = 0
                                        e(1) = C3jk - L * C1;
                                        DeltaE = DeltaE + C3f * exp(-0.5 * e.transpose() * BBB * e);
                                        for (int q2 = 1; q2 <= dmax; q2++) {
                                            e(1) = C3jk - L * (C1 + q2);
                                            xx7 = C3f * exp(-0.5 * e.transpose() * BBB * e);
                                            e(1) = C3jk - L * (C1 - q2);
                                            xx7 = xx7 + C3f * exp(-0.5 * e.transpose() * BBB * e);
                                            DeltaE = DeltaE + xx7;
                                            if (abs(PotEnergyB * PD2) > abs(xx7))
                                                break;
                                        }
                                        PotEnergyBLayer = PotEnergyBLayer + DeltaE;
                                        if (abs(PotEnergyB * PD2) > abs(DeltaE))
                                            break;
                                    }
                                }
                                PotEnergyB = PotEnergyB + PotEnergyBLayer;
                                layer++;
                                //cout << "PotEnergyBLayer = " << PotEnergyBLayer << " PotEnergyB = " << PotEnergyB << endl;
                                //cout << "layer = " << layer << endl;
                            }
                            PotEnergy3BP = PotEnergy3BP + pow(PotEnergyB,3);
                        }
                    }
                }
            }

            PotEnergy3B = PotEnergy3B + parity[iperm] * stme[iperm*nPairs*nop] * PotEnergy3BP;
        }  //  end if(npar>2)
    }   // end sum over permutation
    

    KinEnergy=0.5*3*h2m*KinEnergy;
    PotEnergy3B = vpot3b * PotEnergy3B;

    return PotEnergy+KinEnergy+PotEnergy3B;
}

//============================================================================
vector<VectorXd> SumOverCellsNormal(int dmax, int npar){
    int Nconf = pow(2 * dmax + 1, npar-1); //number of configuration
    vector<VectorXd> d(Nconf);
    VectorXd b(npar);
    for (int i = 0; i < npar-1; i++)  b(i) = 0;
    int counter = 0;

    int k = 0; int checkLayer = 0;
    for(int layer=0; layer < dmax + 1; layer++) {
        for (int i = 0; i < Nconf; i++) {
            checkLayer = 0;
            for(int c=0; c<npar; c++)
                if(abs(checkLayer) < abs(b(c)))
                    checkLayer = abs(b(c));
            if(checkLayer == layer) {
                d[counter] = b;
                counter++;
            }
            for (int j = 0; j < k; j++)
                b(j) = 0;
            b(k)++;
            if (b(k) > dmax)
                b(k) = -dmax;
            for (k = 0; k < npar - 2; k++) {
                if (b(k) != -1)
                    break;
            }
        }
    }
    return d;
}
//============================================================================
vector<VectorXd> SumOverCellsJacobi(int dmax, int npar, MatrixXd Ured){
    int Nconf = pow(2 * dmax + 1, npar-1); //number of configuration
    vector<VectorXd> d(Nconf);
    VectorXd b(npar-1);
    for (int i = 0; i < npar-1; i++)  b(i) = 0;
    int counter = 0;

    int k = 0; int checkLayer = 0;
    for(int layer=0; layer < dmax + 1; layer++) {
        for (int i = 0; i < Nconf; i++) {
            checkLayer = 0;
            for(int c=0; c<npar-1; c++)
                if(abs(checkLayer) < abs(b(c)))
                    checkLayer = abs(b(c));
            if(checkLayer == layer) {
                d[counter] = Ured*b;
                counter++;
            }
            for (int j = 0; j < k; j++)
                b(j) = 0;
            b(k)++;
            if (b(k) > dmax)
                b(k) = -dmax;
            for (k = 0; k < npar - 2; k++) {
                if (b(k) != -1)
                    break;
            }
        }
    }
    return d;
}
//=============================================================================

vector<VectorXd> TwoBodyPairs(int npar)
{
    vector<VectorXd> Cij(npar*(npar - 1) / 2);
    CoordinatsTransformation v(npar);
    int ipair = 0;
    for (int i = 0; i < npar; i++)	{
        for (int j = i + 1; j < npar; j++){
            Cij[ipair] = v.SingleParticle(i, j);
            ipair++;
        }
    }
    return Cij;
}
//=============================================================================
void MatrixElement::PreparePotential(Input &input)
{
    vpot = MatrixXd::Zero(nop, npt);
    apot = MatrixXd::Zero(nop, npt);
//	cout << "PreparePotential: nop= " << nop << "  nterms= " << npt << "\n";
    for (int ipt = 0; ipt < npt; ipt++)
    {
        for (int iop = 0; iop < nop; iop++)
        {
            vpot(iop, ipt) = input.potop[iop].vpot[ipt];
            apot(iop, ipt) = input.potop[iop].aquad[ipt];
//			printf("\t\t iop = %4d   iterm = %4d   vpot = %8.3f   "
//		    "aquad = %8.3f   \n",iop,ipt,vpot(iop,ipt),apot(iop, ipt));
        }
    }
}
//=============================================================================
void MatrixElement::PrepareSpinIsospinME(Input &input)
{
    Operators operators(input);
    stme.resize(nPairs*nPerm*nop);
    //  int keypr = 1;

    int ipair = -1;
    for (int ip = 0; ip < npar; ip++){
        for (int jp = ip + 1; jp < npar; jp++){
            ipair++;
            //    fprintf(input.printfile,
            //	    "\t\t PrepareSpinIsospinME: ipair = %4d   ipar = %4d   jpar = %4d \n",ipair,ip,jp);
            for (int iperm = 0; iperm < nPerm; iperm++){
                for (int iop = 0; iop < nop; iop++){
                    stme[(iperm*nPairs+ipair)*nop+iop] = operators.O(ip, jp, PV[iperm], iop);

                    /* print spin-isospin matrix element */
                    //if (keypr == 1) {
                    // fprintf(input.printfile,"\t\t   iperm = %4d  ",iperm);
                    // for (int i = 0; i < npar; i++) fprintf(input.printfile,"%1d",PV[iperm][i]);
                    //  fprintf(input.printfile,
                    //	 "      iop = %4d  me = %9.5f \n",iop,stme[(iperm*nPairs+ipair)*nop+iop]);
                    //}

                }
            }
        }
    }
}
//=============================================================================
int factorial(int npar)
{
    int N;
    if (npar <= 1) return 1;
    N = npar * factorial(npar - 1);
    return N;
}

int MatrixElement::nextConf(int iConf){
    //cout << "input = ";
    //for(int i = 0; i < npar; i++) cout << bbox[iConf](i);
    //cout << endl;

    for(int i = 0; i < npar; i++){
        if(bbox[iConf](i)<0){
            iConf = iConf+1;//+pow(2*dmax+1, i);
            break;
        } //
        if(bbox[iConf](i)>0){
            iConf = iConf+1;//(2*(dmax-bbox[iConf](i))+1)*pow(2*dmax+1, i);
            break;
        }
    }
    //cout << "output = " << endl;
    //for(int i = 0; i < npar; i++) cout << bbox[iConf](i);
    return iConf;
}

MatrixElement::~MatrixElement()
{
}
