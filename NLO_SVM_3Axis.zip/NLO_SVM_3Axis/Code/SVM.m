classdef SVM < handle
    %Manage the SVM procedure
    
    properties
        data
        RandG, ME
        N, seed, mm0, kk0, mnb;
        bmin, bmax,amin,amax;
		iBoxInf;  basisFileName;
        Norm, H;
        States, StatesCounter;
        Ek, dE;
        nSConf
    end
    
    methods
        function obj = SVM(RandG, data, ME)
            %get vars from data
            obj.Ek = 0; obj.dE = 0;
            obj.RandG = RandG; obj.ME = ME;
            obj.data = data;
            obj.N = data.npar; obj.StatesCounter = 0;
            obj.bmin = data.bmin; obj.bmax = data.bmax;
            obj.amin = data.amin; obj.amax = data.amax;
            obj.mm0 = data.mm0; obj.kk0 = data.kk0;
            obj.mnb = data.mnb;
            obj.nSConf = 2^obj.N;
        end
        
        function obj = initilize(obj,basisFileName)
            %Start the states basis, if there is something in the basis
            %file - use it. Otherwise add first state.
            obj.basisFileName = basisFileName; 
            if isfile(basisFileName)
                fid = fopen(basisFileName,'rt') ;
                S = textscan(fid,'%s','Delimiter','\n'); 
                if isempty(S{1})
                    basisSize = 0;
                else
                    basisSize=str2num(string(S{1}(1)));
                end
                if basisSize > 0
                    obj.getExistingBasis(S{1});
                end
            end
        end
        
        function obj = getExistingBasis(obj,BasisCell)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here basisFileName
            A = zeros(obj.N, obj.N, 3); B = zeros(obj.N, obj.N, 3); s = zeros(obj.N, 3);
            for itr = 1:str2num(string(BasisCell(1)))
                for axis = 1:3
                    tic
                    obj.StatesCounter = itr;
                    lineA = 11*itr+3*axis-12; Atxt = string(BasisCell(lineA));
                    AME = textscan(Atxt,'%s','Delimiter',' '); AME = AME{1};
                    lineB = 11*itr+3*axis-11; Btxt = string(BasisCell(lineB));
                    BME = textscan(Btxt,'%s','Delimiter',' '); BME = BME{1};
                    lineS = 11*itr+3*axis-10; Stxt = string(BasisCell(lineS));
                    SME = textscan(Stxt,'%s','Delimiter',' '); SME = SME{1};

                    for i = 1:obj.N
                        for j = 1:obj.N
                            A(i,j,axis) = str2num(string(AME(obj.N*(i-1)+j)));
                        end
                        B(i,i,axis) = str2num(string(BME(i))); 
                        s(i,axis) = str2num(string(SME(i)));
                    end
                end
            
                lineSpin = 11*itr; SpinIdx = str2num(string(BasisCell(lineSpin)));
                if itr == 1
                    obj.States = State(A, B, s, obj.data.spinConf(:,:,SpinIdx), SpinIdx, obj.data.isospin);
                end
                obj.States(itr) = State(A, B, s, obj.data.spinConf(:,:,SpinIdx), SpinIdx, obj.data.isospin);
                obj.updateNorm(obj.States(itr)); obj.updateH(obj.States(itr));
                msg = "itr = " + num2str(itr) + "    E = " + num2str(obj.getEnergy(),'%.8f')
                toc
            end
        end
        
        function updateNorm(obj, state)
            %calculate ME for Norm with the new state
            indx = obj.StatesCounter;
            obj.Norm(indx, indx) = obj.ME.OL(state, state);
            for i = 1:indx-1
                tempN = obj.ME.OL(obj.States(i), state);
                if isreal(tempN)
                    obj.Norm(i, indx) = tempN;
                else 
                    obj.Norm(i, indx) = 0;
                end
                
                obj.Norm(indx, i) = tempN;
            end
        end
        
        function obj = updateH(obj, state)
            %calculate ME for Norm with the new state
            indx = obj.StatesCounter;
            obj.H(indx, indx) = obj.ME.energy(state, state);
            for i = 1:indx-1
                tempH = obj.ME.energy(obj.States(i), state);
                if isreal(tempH)
                    obj.H(i, indx) = tempH;
                else 
                    obj.H(i, indx) = 0;
                end
                obj.H(indx, i) = obj.H(i, indx);
            end    
        end
        
        function e = getEnergy(obj)
            %save the lowest enery for k states in Ek(k). every 5 state
            %print long msg
            E = eigs(obj.H, obj.Norm, obj.StatesCounter);
            %Update Ek and dE for the selection process
            obj.Ek(obj.StatesCounter) = min(E);
            if obj.StatesCounter>3
                obj.dE = (obj.Ek(obj.StatesCounter-3)-obj.Ek(obj.StatesCounter))/3;
            else
                obj.dE = 1;
            end
            e = min(E);
        end
        
        function obj = SaveStatesToFile(obj,basisFileName)
            %Save last state to .basis file
            fileID = fopen(basisFileName,'w');
            fprintf(fileID, num2str(obj.StatesCounter));
            
            for c = 1:obj.StatesCounter
                for axis = 1:3
                    state = obj.States(c);
                    fprintf(fileID, "\n");
                    %print A
                    for i = 1:obj.N
                        for j = 1:obj.N
                            fprintf(fileID, num2str(state.A(i, j,axis),'%20.12f'));
                            fprintf(fileID, " ");
                        end
                    end
                    fprintf(fileID, "\n");
                    for i = 1:obj.N
                        fprintf(fileID,  num2str(state.B(i,i,axis),'%20.12f'));
                        fprintf(fileID, " ");
                    end
                    fprintf(fileID, "\n");
                    for i = 1:obj.N
                        fprintf(fileID,  num2str(state.s(i,axis),'%20.12f'));
                        fprintf(fileID, " ");
                    end
                end
                %print spin as well
                fprintf(fileID, "\n");
                fprintf(fileID,  num2str(state.spinNum));
                fprintf(fileID, "\n");
            end
            fclose(fileID);
        end
        
        function [newState, D] = getRandomState(obj, SpinIdx)
            %Add a new state and update the Norm and H matrices
            %Create A Matrix
            D = zeros(obj.N, obj.N, 3);
            for i = 1:obj.N
                for j = i+1:obj.N
                    D(i,j, 1) = obj.RandG.rand()*(obj.data.amax-obj.data.amin)+obj.data.amin;
                    D(j,i,1)=D(i,j,1);
                end
            end
            D(:,:,2) = D(:,:,1); D(:,:,3) = D(:,:,1);
            A = obj.getA(D);
            %Create B Matrix and s(shift) vector
            BT = zeros(obj.N,obj.N); B = zeros(obj.N,obj.N,3);
            sT = zeros(obj.N, 1); s = zeros(obj.N,3);
            for i = 1:obj.N
                BT(i,i) = obj.RandG.rand()*(obj.data.bmax-obj.data.bmin)+obj.data.bmin;
                BT(i,i)=	1/BT(i,i)^2;
                sT(i) = 0;%obj.RandG.rand()*obj.data.BoxSize-obj.data.BoxSize/2;
            end
            B(:,:,1) = BT; B(:,:,2) = BT; B(:,:,3) = BT;
            s(:,1) = sT; s(:,2) = sT; s(:,3) = sT;
            
            newState = State(A, B, s, obj.data.spinConf(:,:,SpinIdx), SpinIdx, obj.data.isospin);
            
            obj.updateNorm(newState);
            if obj.validNorm() == 0 
                [newState, D] = obj.getRandomState(SpinIdx);
            end
        end
        
        function obj = addState(obj)
            obj.data.dmax = obj.data.dmaxLow;
            obj.ME = MatrixElements(obj.data, obj.ME.Operators, obj.ME.TOperators);
            obj.StatesCounter = obj.StatesCounter + 1;
            %randomly choose spin config
            SpinIdx = floor(obj.RandG.rand()*obj.data.nspc+1);
            [newStateTemp,D] = obj.getRandomState(SpinIdx);
            obj.updateNorm(newStateTemp); obj.updateH(newStateTemp);
            DT = zeros(obj.N, obj.N, 3, obj.data.mm0+1);
            
            E(1) = obj.getEnergy();
            for k = 1:obj.data.kk0
                for axis = 1:3
                    for c1 = 1:obj.N
                        for c2 = c1+1:obj.N
                            DT(:,:,:,1) = D;
                            for m = 2:obj.data.mm0+1
                                DT(:,:,:,m) = D;
                                DT(c1,c2,axis,m) = obj.RandG.rand()*(obj.data.amax-obj.data.amin)+obj.data.amin;
                                DT(c2,c1,axis,m)=DT(c1,c2,axis,m);
                                A = obj.getA(DT(:,:,:,m));
                                newStateTemp(m) = newStateTemp(1); 
                                newStateTemp(m).A = A;
                                obj.updateNorm(newStateTemp(m));
                                if obj.validNorm()
                                    obj.updateH(newStateTemp(m));
                                    E(m) = obj.getEnergy();
                                else
                                    E(m) = inf;
                                end
                            end

                            newStateTemp(1) = newStateTemp(find(E==min(E), 1));
                            D = DT(:,:,:,find(E==min(E), 1));
                            E(1) = min(E);
                        end
                    end
%                     %upgrade B
%                     for i = 1:obj.N
%                         for m = 2:obj.data.mm0+1
%                             B = newStateTemp(1).B(:,:,:);
%                             B(i,i,axis) = obj.RandG.rand()*(obj.data.bmax-obj.data.bmin)+obj.data.bmin;
%                             B(i,i,axis)=	1/B(i,i,axis)^2;
%                             newStateTemp(m) = newStateTemp(1);
%                             newStateTemp(m).B = B;
%                             obj.updateNorm(newStateTemp(m));
%                             if obj.validNorm()
%                                 obj.updateH(newStateTemp(m));
%                                 E(m) = obj.getEnergy();
%                             else
%                                 E(m) = inf;
%                             end
%                         end
%                         newStateTemp(1) = newStateTemp(find(E==min(E), 1));
%                         E(1) = min(E);
%                     end
%                     %Upgrade S
%                     for i = 1:obj.N
%                         for m = 2:obj.data.mm0+1
%                             S = newStateTemp(1).s(:,:);
%                             S(i,axis) = obj.RandG.rand()*obj.data.BoxSize-obj.data.BoxSize/2;
%                             newStateTemp(m) = newStateTemp(1);
%                             newStateTemp(m).s = S;
%                             obj.updateNorm(newStateTemp(m));
%                             if obj.validNorm()
%                                 obj.updateH(newStateTemp(m));
%                                 E(m) = obj.getEnergy();
%                             else
%                                 E(m) = inf;
%                             end
%                         end
%                         newStateTemp(1) = newStateTemp(find(E==min(E), 1));
%                         E(1) = min(E);
%                     end
                end
            end
            if obj.StatesCounter == 1
                obj.States = newStateTemp(1);
            else
                obj.States(obj.StatesCounter) = newStateTemp(1);
            end
            obj.data.dmax = obj.ME.data.dmaxHigh;
            obj.ME = MatrixElements(obj.data, obj.ME.Operators, obj.ME.TOperators);
            
            obj.updateNorm(newStateTemp(1)); obj.updateH(newStateTemp(1));
        end
        
        function A = getA(obj, D)
            A = zeros(obj.N,obj.N, 3);
            for axis = 1:3
                for i = 1:obj.N
                    for j = i:obj.N
                        if i == j
                            for k = 1:obj.N
                                if i ~= k
                                    A(i, j,axis) = A(i, j,axis) + 2 * D(i, k,axis)^-2;
                                end
                            end
                        else
                            A(i, j, axis) = -2 * D(i, j, axis)^-2;
                            A(j, i, axis) = A(i, j, axis);
                        end
                    end
                end
            end
        end
        
        function output = validNorm(obj)
            %check if the Norm matrix is valid - contains no zeros eigenvalues.
            output = true; itr=obj.StatesCounter;
            for i=1:obj.StatesCounter-1
                vdotv = obj.Norm(itr, i) / sqrt(obj.Norm(i, i) * obj.Norm(itr, itr));
                if vdotv > 0.99
                    output = false;
                end
            end
            if obj.Norm(itr, itr) < 1e-7
                output = false;
            end
            if min(eigs(obj.Norm,obj.StatesCounter)) < 2e-8
                output = false;
            end
        end
    end
end

