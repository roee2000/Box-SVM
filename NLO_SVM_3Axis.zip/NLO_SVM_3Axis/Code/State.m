classdef State
    %State of N particles with the gauusian structure of 3 axis and |S,T>
    
    properties
        A,B,s;
        spin, spinNum, isospin;
    end
    
    methods
        function obj = State(A, B, s, spin, spinNum, isospin)
            %Copy state properties
            obj.A = A; obj.B = B; obj.s = s;
            obj.spin = spin; obj.spinNum = spinNum;
            obj.isospin=isospin;
        end
    end
end

