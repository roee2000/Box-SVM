%%%%%%                NO MINUS IN ISOSPIN EXCHANGE                %%%%%

classdef MatrixElements
    %Calculate OL,V,T between states pair.
    
    properties
        L, nPairs; Mass;
        PM, PV,parity, nPerm;
        nConf, bbox;
        data; TBP, N;
        Operators, TOperators;
    end
    
    methods
        function obj = MatrixElements(data, Operators,TOperators)
            %Initilize the class from the data.
            obj.L = data.BoxSize; obj.data = data;
            obj.nPairs = data.npar*(data.npar-1)/2;
            obj.nPerm = factorial(data.npar);
            obj.nConf = (2 * data.dmax + 1)^data.npar;
            
            obj.Mass = diag(data.xm);
            %create TBP - Two Body Pair set of nPair vectors.
            obj.TBP = zeros(obj.nPairs, data.npar);
            ipair = 1; obj.N = data.npar;
            for i = 1:data.npar
                for j = i+1:data.npar
                    obj.TBP(ipair, i) = 1; obj.TBP(ipair, j) = -1;
                    ipair = ipair + 1;
                end
            end
            %create bbox - all combination of N particle shifts for 1 axis.
            b = zeros(1, data.npar) - data.dmax; 
            obj.bbox = zeros(obj.nConf, data.npar);
            for ibbox = 1:obj.nConf - 1
                obj.bbox(ibbox, :) = b;
                b(1) = b(1) + 1;
                for i = 1:data.npar
                    if b(i) == data.dmax + 1
                        b(i+1) = b(i+1) + 1;
                        b(i) = -data.dmax;
                    end
                end
            end
            obj.bbox(obj.nConf, :) = b;
            %create perm - all combination of N particle permutaion.
            obj.PV = perms(1:data.npar); obj.PM = zeros(data.npar, data.npar, obj.nPerm);
            for i = 1:obj.nPerm
                for j = 1:data.npar
                    obj.PM(j,obj.PV(i, j), i) = 1;
                end
                obj.parity(i) = det(obj.PM(:,:, i));
            end
            %Calculate all Operators
            if Operators == -inf
                for sp1 = 1:data.nspc
                    for sp2 = 1:data.nspc
                        for ipair = 1:obj.nPairs
                            a = find(obj.TBP(ipair,:)==1); b = find(obj.TBP(ipair,:)==-1);
                            for iperm = 1:obj.nPerm
                                for iop = 1:obj.data.nop
                                    obj.Operators(sp1, sp2, a, b, iperm, iop) = ...
                                        obj.Operator(obj.data.spinConf(:,:,sp1), obj.data.spinConf(:,:,sp2),a,b, iperm, iop-1);
                                    for i = 1:3
                                        for j = 1:3
                                            obj.TOperators(sp1,sp2,a,b,i,j,iperm,iop) = ...
                                                obj.TOperator(obj.data.spinConf(:,:,sp1),obj.data.spinConf(:,:,sp2),a,b,i,j,iperm,iop-1);
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            else
                obj.Operators = Operators;
                obj.TOperators = TOperators;
            end
        end
        
        function OL = OL(obj, state1, state2)
            %Calcualte the overlap between 2 states with eq (11) from the
            %ReseachProposalStageB by Motti
            OL = 0; 
            for iperm = 1:obj.nPerm
                OLAxis = zeros(1, 3);
                SISPart = obj.Operators(state1.spinNum, state2.spinNum, 1, 2, iperm, 1);
                if SISPart == 0
                    continue;
                end
                for axis = 1:3
                    A1 = state1.A(:,:,axis); B1 = state1.B(:,:,axis); s1 = state1.s(:,axis); Bs1 = B1*s1;
                    A2_0 = state2.A(:,:,axis); B2_0 = state2.B(:,:,axis); s2_0 = state2.s(:,axis);

                    A2 = obj.PM(:,:,iperm)' * A2_0 * obj.PM(:,:,iperm);
                    B2 = obj.PM(:,:,iperm)' * B2_0 * obj.PM(:,:,iperm);
                    s2 = obj.PM(:,:,iperm)' * s2_0;
                    Bs2 = B2*s2; Bs12 = Bs1 + Bs2; AB1 = A1+B1;
                    C = A1 + B1 + A2 + B2; CInv = C^-1;
                    sBs1 = -0.5*s1'*Bs1; sBs2 = -0.5*s2'*Bs2; sBs12 = sBs1 + sBs2;
                    for iconf = 1:obj.nConf
                         d = obj.L*AB1*obj.bbox(iconf,:)' + Bs12;
                         x4 = 0.5*d'*CInv*d;
                         x6 = -0.5*obj.L^2*obj.bbox(iconf,:)*(2/obj.L*Bs1+AB1*obj.bbox(iconf,:)');
                         OLAxis(axis) = OLAxis(axis) + exp(sBs12+x4+x6);
                    end
                    OLAxis(axis) = OLAxis(axis)/sqrt(det(C));
                end
                OL = OL + obj.parity(iperm)*SISPart*OLAxis(1)*OLAxis(2)*OLAxis(3);
            end
        end
        
        function E = energy(obj, state1, state2)
            %Calcualte the <psi1|H|psi2> ME between 2 states by summing 
            %eq. (12)+(13)+(14) from ReseachProposalStageB.pdf by Moti
            KinEnergy = 0; PotEnergy2B = 0; PotEnergy3B = 0;
            PotEnergy2BT1 = 0;  PotEnergy2BT2 = 0;
            B = zeros(2); I = eye(2);
            for iperm = 1:obj.nPerm
                PotEnergy3BA = zeros(obj.N-2,obj.N-2,obj.N-2,3,3);
                PotEnergyA = zeros(obj.nPairs,obj.data.npt,3);
                PotEnergyT = zeros(obj.nPairs,obj.data.npt,3,3);
                SISPot2BPart = zeros(obj.nPairs,obj.data.npt);
                SISPot2BT = zeros(obj.nPairs,obj.data.nTpt,3,3);
                SISKinPart = obj.Operators(state1.spinNum, state2.spinNum, 1, 2, iperm, 1);
                OLAxis = zeros(1, 3); KinAxis = zeros(1, 3);
                for axis = 1:3
                    A1 = state1.A(:,:,axis); B1 = state1.B(:,:,axis); s1 = state1.s(:,axis); Bs1 = B1*s1;
                    A2_0 = state2.A(:,:,axis); B2_0 = state2.B(:,:,axis); s2_0 = state2.s(:,axis);

                    A2 = obj.PM(:,:,iperm)' * A2_0 * obj.PM(:,:,iperm);
                    B2 = obj.PM(:,:,iperm)' * B2_0 * obj.PM(:,:,iperm);
                    s2 = obj.PM(:,:,iperm)' * s2_0;
                    Bs2 = B2*s2; Bs12 = Bs1 + Bs2; AB1 = A1+B1;  AB2 = A2+B2;
                    sBs1 = -0.5*s1'*B1*s1; sBs2 = -0.5*s2'*B2*s2; sBs12 = sBs1 + sBs2;
                    C = A1 + B1 + A2 + B2; CInv = C^-1;
                    sqInvDetC = 1/sqrt(det(C));
                    
                    %%%         Calculate kinetic energy
                    if SISKinPart ~= 0
                        y1 = trace(AB1*CInv*AB2);
                        for iconf = 1:obj.nConf
                             d = obj.L*AB1*obj.bbox(iconf,:)' + Bs1;
                             yy = AB2*CInv*d-AB1*CInv*Bs2; y2 = yy'*yy;
                             d = d + Bs2;
                             x4 = 0.5*d'*CInv*d;
                             x6 = -0.5*obj.L^2*obj.bbox(iconf,:)*(2/obj.L*Bs1+AB1*obj.bbox(iconf,:)');
                             y3 = sqInvDetC*exp(sBs12+x4+x6);
                             OLAxis(axis) = OLAxis(axis) + y3;
                             KinAxis(axis) = KinAxis(axis) + (y1-y2)*y3;
                        end
                    end
                    %%%         Calculate 2 body potential energy
                    for ipair = 1:obj.nPairs
                        i = find(obj.TBP(ipair,:)==1); j = find(obj.TBP(ipair,:)==-1);
                        for ipt = 1:obj.data.npt
                            if axis == 1
                                for iop = 1:obj.data.nop
                                    SISPot2BPart(ipair,ipt) = SISPot2BPart(ipair,ipt) +...
                                        obj.data.vpot(ipt,iop)*obj.Operators(state1.spinNum, state2.spinNum, i, j, iperm, iop);
                                end
                            end
                            if SISPot2BPart(ipair,ipt) ~= 0
                            	s = obj.TBP(ipair,:)*CInv*obj.TBP(ipair,:)';
                                x9 = sqInvDetC*sqrt(1.0 / (2.0*obj.data.apot(ipt)*s + 1));
                                C = obj.data.apot(ipt)/(2.0*obj.data.apot(ipt)*s + 1);
                                for iconf = 1:obj.nConf
                                    d = obj.L*AB1*obj.bbox(iconf,:)' + Bs12; CInvd = CInv*d;
                                    x4 = 0.5*d'*CInv*d;
                                    x5 = -0.5*obj.L^2*obj.bbox(iconf,:)*(2/obj.L*Bs1+AB1*obj.bbox(iconf,:)');
                                    rC = obj.TBP(ipair,:)*CInvd;
                                    Cpot = x9*exp(sBs12+x4+x5);
                                    for q=-obj.data.dmax:obj.data.dmax
                                        r = -obj.L*q + rC;
                                        PotEnergyA(ipair,ipt,axis) = PotEnergyA(ipair,ipt,axis) + Cpot*exp(-r^2*C);
                                    end
                                end
                            end
                        end
                    end
                    
                    %%%         Calculate Tensor potential energy
                    
                    for ipair = 1:obj.nPairs
                        a = find(obj.TBP(ipair,:)==1); b = find(obj.TBP(ipair,:)==-1);
                        if axis == 1
                            for ipt = 1:obj.data.nTpt
                                for iop = 1:obj.data.nTop
                                    for i = 1:3
                                        for j = 1:3
                                            SISPot2BT(ipair,ipt,i,j) = SISPot2BT(ipair,ipt,i,j) + ...
                                                obj.data.aTpot(ipt)*obj.data.vTpot(ipt,iop)*obj.TOperators(state1.spinNum, state2.spinNum, a, b,i,j, iperm, iop);
                                        end
                                    end
                                end
                            end
                        end
                        for ipt = 1:obj.data.nTpt
                            s = obj.TBP(ipair,:)*CInv*obj.TBP(ipair,:)';
                            x9 = sqInvDetC*sqrt(1.0 / (2.0*obj.data.aTpot(ipt)*s + 1));
                            C = obj.data.aTpot(ipt)/(2.0*obj.data.aTpot(ipt)*s + 1);
                            CTInv = (A1 + B1 + A2 + B2 + 2*obj.data.aTpot(ipt)*obj.TBP(ipair,:)'*obj.TBP(ipair,:))^-1;
                            for iconf = 1:obj.nConf
                                d = obj.L*AB1*obj.bbox(iconf,:)' + Bs12; 
                                CInvd = CInv*d;
                                x4 = 0.5*d'*CInvd;
                                x5 = -0.5*obj.L^2*obj.bbox(iconf,:)*(2/obj.L*Bs1+AB1*obj.bbox(iconf,:)');
                                Cpot = x9*exp(sBs12+x4+x5);
                                for q=-obj.data.dmax:obj.data.dmax
                                    rC = obj.TBP(ipair,:)*CInvd;
                                    rCT = obj.TBP(ipair,:)*CTInv*(d-2*obj.data.aTpot(ipt)*obj.L*q*obj.TBP(ipair,:)');
                                    R = -obj.L*q + rC; 
                                    ADD = Cpot*exp(-R^2*C);
                                    RT = -obj.L*q + rCT;
                                    sT = obj.TBP(ipair,:)*CTInv*obj.TBP(ipair,:)';
                                    PotEnergyT(ipair,ipt,axis,1) = PotEnergyT(ipair,ipt,axis,1) + ADD;
                                    PotEnergyT(ipair,ipt,axis,2) = PotEnergyT(ipair,ipt,axis,2) + ADD*RT;
                                    PotEnergyT(ipair,ipt,axis,3) = PotEnergyT(ipair,ipt,axis,3) + ADD*(RT^2+sT);
                                end
                            end
                        end
                    end
                    %%%         Calculate 3 body potential energy
                    SIS3BPotPart = obj.data.vpot3b*obj.Operators(state1.spinNum, state2.spinNum, 1, 2, iperm, 1);
                    if SIS3BPotPart ~= 0
                    for i = 1:obj.N-2
                        for j = i+1:obj.N-1
                            for k = j+1:obj.N
                                for cyc =1:3
                                	if cyc == 1
                                        i1 = i; j1 = j; k1=k; end
                                    if cyc == 2
                                        i1 = j; j1 = k; k1=i; end
                                    if cyc == 3
                                        i1 = k; j1 = i; k1=j; end
                                    Cik = zeros(obj.N, 1); Cik(i1)=1; Cik(k1)=-1;
                                    Cjk = zeros(obj.N, 1); Cjk(j1)=1; Cjk(k1)=-1;
                                    B(1,1) = Cik'*CInv*Cik; B(1,2) = Cik'*CInv*Cjk;
                                    B(2,1) = Cjk'*CInv*Cik; B(2,2) = Cjk'*CInv*Cjk;
                                   
                                    BB = I+2*obj.data.apot3b*B;
                                    BBB = B^-1*(I-BB^-1);
                                    xx1 = sqrt(1.0 / det(BB));
                                    Temp = zeros(1,obj.nConf);
                                    for iconf = 1:obj.nConf
                                        e = zeros(2,1);
                                        d = obj.L*AB1*obj.bbox(iconf,:)' + Bs12; dCinv = d'*CInv;
                                        xx2 = 0.5*dCinv*d;
                                        xx3 = -0.5*obj.L^2*obj.bbox(iconf,:)*(2/obj.L*Bs1+AB1*obj.bbox(iconf,:)');
                                        C3f = sqInvDetC*exp(xx2+xx3+sBs12)*xx1;
                                        C3ik = dCinv*Cik; C3jk = dCinv*Cjk;
                                        for q1=-obj.data.dmax:obj.data.dmax
                                            e(1)=C3ik-obj.L*q1; CC = e(1)^2*BBB(1,1);
                                            for q2=-obj.data.dmax:obj.data.dmax
                                                e(2)=C3jk-obj.L*q2;
                                                C = CC+ e(2)^2*BBB(2,2)+2*e(1)*e(2)*BBB(1,2);
                                                Temp(iconf) = Temp(iconf) + C3f*exp(-0.5*C);
                                            end
                                        end
                                    end
                                    for iconf = 1:obj.nConf
                                        PotEnergy3BA(i,j-1,k-2,cyc,axis) = PotEnergy3BA(i,j-1,k-2,cyc,axis)+Temp(iconf);
                                    end
                                end
                            end
                        end
                    end
                    end
                end
                %%%         Sum All Axis Kinetic Energy
                KinEnergy = KinEnergy + obj.parity(iperm)*SISKinPart*KinAxis(1)*OLAxis(2)*OLAxis(3);
                KinEnergy = KinEnergy + obj.parity(iperm)*SISKinPart*KinAxis(2)*OLAxis(3)*OLAxis(1);
                KinEnergy = KinEnergy + obj.parity(iperm)*SISKinPart*KinAxis(3)*OLAxis(1)*OLAxis(2);
                %%%         Mult All Axis Potential Energy for central 2B
                for ipair = 1:obj.nPairs
                    for ipt = 1:obj.data.npt
                        PotEnergy2B = PotEnergy2B + obj.parity(iperm)*SISPot2BPart(ipair,ipt)...
                        *PotEnergyA(ipair,ipt,1)*PotEnergyA(ipair,ipt,2)*PotEnergyA(ipair,ipt,3);
                    end
                end
                
                for ipair = 1:obj.nPairs
                    for ipt = 1:obj.data.npt
                %%%    Mult All Axis Potential Energy for central 2B Tensor Part 1
                        SMET = 0;
                        for j = 1:3
                            SMET = SMET + SISPot2BT(ipair,ipt,j,j);
                        end
                        for i = 1:3
                            for j = 1:3
                                m =[1 1 1]; m(i) = m(i) + 1; m(j) = m(j) + 1;
                                PotEnergy2BT1 = PotEnergy2BT1 + 3*obj.parity(iperm)*SISPot2BT(ipair,ipt,i,j)...
                                *PotEnergyT(ipair,ipt,1,m(1))*PotEnergyT(ipair,ipt,2,m(2))*PotEnergyT(ipair,ipt,3,m(3));
                            end
                            m =[1 1 1]; m(i) = 3;
                            
                            PotEnergy2BT2 = PotEnergy2BT2 - obj.parity(iperm)*SMET... %% obj.data.apot(ipt)/6* (?)
                                *PotEnergyT(ipair,ipt,1,m(1))*PotEnergyT(ipair,ipt,2,m(2))*PotEnergyT(ipair,ipt,3,m(3));
                        end
                    end
                end
                %%%         Counter of this permutaion
                PotEnergy3BTemp = 0;
                for i = 1:obj.N-2
                    for j = i+1:obj.N-1
                        for k = j+1:obj.N
                            for cyc = 1:3
                                PotEnergy3BTemp = PotEnergy3BTemp + PotEnergy3BA(i,j-1,k-2,cyc,1)*...
                                    PotEnergy3BA(i,j-1,k-2,cyc,2)*PotEnergy3BA(i,j-1,k-2,cyc,3);
                            end
                        end
                    end
                end
                PotEnergy3B = PotEnergy3B + PotEnergy3BTemp*obj.parity(iperm)*SIS3BPotPart;
            end
            KinEnergy = KinEnergy*obj.data.h2m/2;
            PotEnergy2BT = PotEnergy2BT1 + PotEnergy2BT2;
            E = KinEnergy+PotEnergy2B+PotEnergy3B + PotEnergy2BT;
        end
        
        function output = Operator(obj, spin1, spin2, ipar, jpar, perm, kind)
            x = 0; y = 0;
            tempSpin2 = spin2; isoSpin = obj.data.isospin; tempIso2 = isoSpin;
            %%%make exchanges by the kind of the operator between the i,j particles.
            if kind == 1 || kind == 2
                for n = 1:size(spin1, 1)
                    tempSpin2(n, ipar+1) = spin2(n, jpar+1);
                    tempSpin2(n, jpar+1) = spin2(n, ipar+1);
                end
            end
            if kind == 1 || kind == 3
                for n = 1:size(isoSpin, 1)
                    tempIso2(n, ipar+1) = isoSpin(n, jpar+1);
                    tempIso2(n, jpar+1) = isoSpin(n, ipar+1);
                    tempIso2(n, 1) = -isoSpin(n, 1);
                end
            end
            %%%sum the coeff of spin/iso states which are the same in x/y.
            for i1 = 1:size(spin1, 1)
                for i2 = 1:size(tempSpin2, 1)
                    if spin1(i1,2:obj.N+1) == tempSpin2(i2,obj.PV(perm, 1:obj.N)+1)
                        x = x + spin1(i1, 1)*tempSpin2(i2, 1);
                    end
                end
            end
            for i1 = 1:size(isoSpin, 1)
                for i2 = 1:size(tempIso2, 1)
                    if isoSpin(i1,2:obj.N+1) == tempIso2(i2,obj.PV(perm, 1:obj.N)+1)
                        y = y + isoSpin(i1, 1)*tempIso2(i2,1);
                    end
                end
            end
            output = x*y;
        end
        
        function output = TOperator(obj, spin1, spin2, ipar, jpar, i, j, perm, kind)
            x = 0; y = 0;
            tempSpin2 = spin2; isoSpin = obj.data.isospin; tempIso2 = isoSpin;
            %%%make exchanges by the kind of the operator between the i,j particles.
            if kind == 1 || kind == 2
                for n = 1:size(spin2, 1)
                    tempSpin2(n, ipar+1) = spin2(n, jpar+1);
                    tempSpin2(n, jpar+1) = spin2(n, ipar+1);
                end
            end
            %%%%%%                   Tensor Part                    %%%%%%
            for n = 1:size(spin2, 1)
                if i == 1 %%sigmaX: 1=>2, 2=>1: a=-a+3
                    tempSpin2(n, ipar+1) = -tempSpin2(n, ipar+1)+3;
                elseif i== 2 %%sigmaY: N(2) = -i, N(1) = i, 1=>2, 2=>1: a=-a+3
                    tempSpin2(n, 1) = (-2*tempSpin2(n, ipar+1)+3)*1i*tempSpin2(n, 1);
                    tempSpin2(n, ipar+1) = -tempSpin2(n, ipar+1)+3;
                else %%sigmaZ: N(2) = 1, N(1) = -1, N = 2*a-3
                    tempSpin2(n, 1) = (2*tempSpin2(n, ipar+1)-3)*tempSpin2(n, 1);
                end
            %%%%%                Same with j particle              %%%%%%%
                if j == 1 %%sigmaX: 1=>2, 2=>1: a=-a+3
                    tempSpin2(n, jpar+1) = -tempSpin2(n, jpar+1)+3;
                elseif j== 2 %%sigmaY: N(2) = -i, N(1) = i, 1=>2, 2=>1: a=-a+3
                    tempSpin2(n, 1) = (-2*tempSpin2(n, jpar+1)+3)*1i*tempSpin2(n, 1);
                    tempSpin2(n, jpar+1) = -tempSpin2(n, jpar+1)+3;
                else %%sigmaZ: N(2) = 1, N(1) = -1, N = 2*a-3
                    tempSpin2(n, 1) = (2*tempSpin2(n, jpar+1)-3)*tempSpin2(n, 1);
                end
            end
            %%%%%%                 End Tensor Part                  %%%%%%
            if kind == 1 || kind == 3
                for n = 1:size(isoSpin, 1)
                    tempIso2(n, ipar+1) = isoSpin(n, jpar+1);
                    tempIso2(n, jpar+1) = isoSpin(n, ipar+1);
                    tempIso2(n, 1) = isoSpin(n, 1); %%NO MINUS SUPER IMPORTANT
                end
            end
            %%%sum the coeff of spin/iso states which are the same in x/y.
            for i1 = 1:size(spin1, 1)
                for i2 = 1:size(tempSpin2, 1)
                    if spin1(i1,2:obj.N+1) == tempSpin2(i2,obj.PV(perm, 1:obj.N)+1)
                        x = x + spin1(i1, 1)*tempSpin2(i2, 1);
                    end
                end
            end
            for i1 = 1:size(isoSpin, 1)
                for i2 = 1:size(tempIso2, 1)
                    if isoSpin(i1,2:obj.N+1) == tempIso2(i2,obj.PV(perm, 1:obj.N)+1)
                        y = y + isoSpin(i1, 1)*tempIso2(i2,1);
                    end
                end
            end
            output = x*y;
        end
    end
end

