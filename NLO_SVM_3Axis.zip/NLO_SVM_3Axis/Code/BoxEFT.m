%%%%%%%%%         N body penomelogical gauusian potential         %%%%%%%%%
%% Section 0 - tests
A11 = 0.002367988773; a = 1; d = 1/sqrt(A11+a); alpha = 10^-4; 
B11 = 0.001111111111; b = 1/sqrt(B11);
CS3T1 = 20;
D = [2/d^2+2/b^2, -2/d^2; -2/d^2, 2/d^2+2/b^2];
DZ = D + [4*alpha, -4*alpha; -4*alpha, 4*alpha];
Sx = [1, -1]*D^(-1)*[1; -1];
Sz = [1, -1]*DZ^(-1)*[1; -1];
VT2 = CS3T1*sqrt(1/det(D)^2/det(DZ))*(2*Sx+Sz)*2; %inculde permutaion
VT1 = 3*CS3T1*sqrt(1/det(D)^2/det(DZ))*(-2*Sx+Sz)*2; %inculde permutaion

VTOT = -4*CS3T1*sqrt(1/det(D)^2/det(DZ))*(Sx-Sz)*2 %inculde permutaion
VT2 = num2str((VT2),'%20.4f')
%% section 1 : get parameters from txt
clearvars; close all;
fileName = "nn";
data = InputData(fileName + ".inp");
dEk = data.h2m*data.npar/2/(3*data.bmax)^2;
msg = "dEkin = " + num2str(dEk) + "    duo to the bmax"
RandG = RandStream('mt19937ar','Seed',abs(2*data.irand));
ME = MatrixElements(data, -inf, 0);
SVM = SVM(RandG, data, ME);
N = data.npar;
SVM.initilize(fileName + ".basis");

%% section 2 - SVM
for itr = SVM.StatesCounter:data.mnb-1
    tic
    SVM.addState();
    SVM.SaveStatesToFile(fileName + ".basis");
    msg = "itr = " + num2str(itr+1) + "    E = " + num2str(SVM.getEnergy(),'%.8f')
    toc
end

%% section3 - analyze A,B,s dis
BList = 0; sList = 0; AList = SVM.States(1).A(1,2,1);
for i=1:SVM.StatesCounter
    for axis = 1:3
        for n = 1:N
            sList(N*i-n+1) = SVM.States(i).s(n,axis);
            BList(N*i-n+1) = SVM.States(i).B(n,n,axis);
            for m = n+1:N
                AList(size(AList,2)+1) = SVM.States(i).A(n,m,axis);
            end
        end
    end
end
BdList = 1./sqrt(BList); AdList = sqrt(-2./AList);

histogram(sList,8);
title('sList');
figure
histogram(BdList,8);
title('B_{ME} Values Histogram for bmin = 0.001, bmax = ?', 'fontsize', 16);
grid on; box on;
xlabel('b_{ME} with bmax = 3[fm]', 'fontsize', 16); 
ylabel('counter', 'fontsize', 16); 
figure
histogram(AdList,8)
title('AdList')