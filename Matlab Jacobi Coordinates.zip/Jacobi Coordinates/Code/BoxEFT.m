%% N body penomelogical gauusian potential
%% section 1 : get parameters from txt
clearvars; close all;
fileName = "He3";
data = InputData(fileName + ".inp");
RandG = RandStream('mt19937ar','Seed',abs(2*data.irand));
ME = MatrixElements(data);
SVM = SVM(RandG, data, ME);
N = data.npar;
SVM.initilize(fileName + ".basis");
%% section 2 - SVM
for itr = SVM.StatesCounter:data.mnb
    tic
    SVM.addState();
    SVM.SaveStatesToFile(fileName + ".basis");
    msg = "itr = " + num2str(itr+1) + "    E = " + num2str(SVM.getEnergy(),'%.8f')
    toc
end

%% section3 - analyze A,B,s dis
AList = zeros(1,3*SVM.StatesCounter);
for i=1:SVM.StatesCounter
    AList(3*i-2) = SVM.States(i).A(1,2);
    AList(3*i-1) = SVM.States(i).A(1,3);
    AList(3*i) = SVM.States(i).A(2,3);
end
AdList = sqrt(-2./AList);

histogram(AdList,8)
title('AdList')
grid on; box on;
xlabel('a_{ME} with amax = 3[fm]', 'fontsize', 16); 
ylabel('counter', 'fontsize', 16); 